<div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">
	<div class="carousel-inner" role="listbox">
		<?php include("list_pekerjaan.php")?>
	</div>
	<a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
		<span class="carousel-control-prev-icon" aria-hidden="false"></span>
		<span class="sr-only">Previous</span>
	</a>
	<a class="carousel-control-next op1" href="#carouselExampleIndicators" role="button" data-slide="next">
		<span class="carousel-control-next-icon" aria-hidden="true"></span>
		<span class="sr-only">Next</span>
	</a>
</div>
