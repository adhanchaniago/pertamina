<!-- Footer -->
    <footer class="py-0 footer_bg">
      <div class="container">
        <p class="m-0 text-center text-white" align="center">Copyright &copy; Teitra Mega 2018</p>
      </div>
      </footer>
      <!-- /.container -->