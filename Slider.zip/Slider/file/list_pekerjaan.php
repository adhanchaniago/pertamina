<div class="carousel-item active" style="background-image: url('#')">
<div class="carousel-caption d-md-block slider_item">
	<div class="tittle" >
		<div class="title-p">PEKERJAAN HARI INI</div>
		<div class="date-picker"><?php include('date_picker.php') ?></div>
	</div>
	<div class="to-do">
		<table border="0" class="tb_item" align="center">
  			<tr valign="top">
   				<td colspan="5"><h2><font face="Arial Black">Nama Pekerjaan</font></h2></td>
  			</tr>
  			<tr align="left" valign="top">
   				<td width="200">No. Pekerjaan</td>
   				<td>:</td>
   				<td width="400">A/VA01/112</td>
   				<td width="250">Progress Sebelumnya</td>
   				<td width="200">: 30%</td>
  			</tr>
  			<tr align="left" valign="top">
   				<td>Pelaksana</td>
   				<td>:</td>
   				<td> #Nama Pelaksana</td>
   				<td>Target Hari Ini</td>
   				<td>: 40%</td>
  			</tr>
  			<tr align="left" valign="top">
   				<td>Pengawas</td>
   				<td>:</td>
   				<td> #Nama Pengawas</td>
   				<td>Mulai</td>
   				<td>: 09:00 WIB</td>
  			</tr>
	 	 	<tr align="left" valign="top" valign="top">
   				<td>Pekerja</td>
   				<td>:</td>
   				<td>
   					<ol type="1">
						<li>#pekerja 1</li>
   						<li>#pekerja 2</li>
   						<li>#pekerja 3</li>
   					</ol>
   				</td>
   				<td>Selesai <br> Durasi</td>
   				<td>: 15:00 WIB<br>: 6 Jam</td>
	  		</tr>
	 	 	<tr valign="top">
		  		<td colspan="5">
		  			<table border="1" width="100%">
	  				<tr align="left" valign="top">
	  					<td>Pekerjaan Hari Ini :
	  						<ol type="1">
	  							<li>pekerjaan</li>
	  							<li>pekerjaan</li><li>pekerjaan</li><li>pekerjaan</li>
	  						</ol>
	  					</td>
	  					<td>Keterangan
	  						<ol type="1">
	  							<li>Keterangan 1</li>
	  							<li>Keterangan 2</li>
	  						</ol>
	  					</td>
	  				</tr>
	  			</table>
	  		</td>
	  	</tr>
 		</table>
 	</div>
 </div>
</div>
<div class="carousel-item" style="background-image: url('#')">
<div class="carousel-caption d-md-block slider_item">
	<div class="tittle" >
		<div class="title-p">PEKERJAAN HARI INI</div>
		<div class="date-picker"><?php include('date_picker.php') ?></div>
	</div>
	<div class="to-do">
		<table border="0" class="tb_item" align="center">
  			<tr valign="top">
   				<td colspan="5"><h2><font face="Arial Black">Nama Pekerjaan</font></h2></td>
  			</tr>
  			<tr align="left" valign="top">
   				<td width="200">No. Pekerjaan</td>
   				<td>:</td>
   				<td width="400">A/VA01/112</td>
   				<td width="250">Progress Sebelumnya</td>
   				<td width="200">: 30%</td>
  			</tr>
  			<tr align="left" valign="top">
   				<td>Pelaksana</td>
   				<td>:</td>
   				<td> #Nama Pelaksana</td>
   				<td>Target Hari Ini</td>
   				<td>: 40%</td>
  			</tr>
  			<tr align="left" valign="top">
   				<td>Pengawas</td>
   				<td>:</td>
   				<td> #Nama Pengawas</td>
   				<td>Mulai</td>
   				<td>: 09:00 WIB</td>
  			</tr>
	 	 	<tr align="left" valign="top" valign="top">
   				<td>Pekerja</td>
   				<td>:</td>
   				<td>
   					<ol type="1">
						<li>#pekerja 1</li>
   						<li>#pekerja 2</li>
   						<li>#pekerja 3</li>
   					</ol>
   				</td>
   				<td>Selesai <br> Durasi</td>
   				<td>: 15:00 WIB<br>: 6 Jam</td>
	  		</tr>
	 	 	<tr valign="top">
		  		<td colspan="5">
		  			<table border="1" width="100%">
	  				<tr align="left" valign="top">
	  					<td>Pekerjaan Hari Ini :
	  						<ol type="1">
	  							<li>pekerjaan</li>
	  							<li>pekerjaan</li><li>pekerjaan</li><li>pekerjaan</li>
	  						</ol>
	  					</td>
	  					<td>Keterangan
	  						<ol type="1">
	  							<li>Keterangan 1</li>
	  							<li>Keterangan 2</li>
	  						</ol>
	  					</td>
	  				</tr>
	  			</table>
	  		</td>
	  	</tr>
 		</table>
 	</div>
 </div>
</div>